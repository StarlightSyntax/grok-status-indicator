# Changelog

All notable changes to this project will be documented in this file.

## [1.0.2] - 2026-05-06

### Added
- Visible version number in the widget footer (v1.0.2)
- Proper changelog tracking

### Changed
- Cleaned up all console.log statements for production
- Improved overall code quality and stability

### Fixed
- Service detail modals now open reliably on first click
- Timezone selector is now fully functional
- Panel positioning improved (smart edge detection)
- Dragging no longer accidentally opens the panel

---

## [1.0.1] - 2026-05-06 (Alpha)

### Added
- Initial release
- Live status widget for grok.com and status.x.ai
- Draggable panel with smart positioning
- Colored square metrics matching official status.x.ai design
- Clickable service pills with detail modals
- Timezone selector
- Credits to @StarlightSyntax and Grok

### Features
- Real-time data every 45 seconds
- Native Grok dark UI
- Keyboard shortcut (Ctrl/Cmd + Shift + S)
- Cross-browser support (Chrome + Firefox)

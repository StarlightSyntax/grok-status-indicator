// content.js - Injects and manages the Status Indicator widget on grok.com and status.x.ai
// Listens to chrome.storage for live updates from background worker
// Fully self-contained, Grok-native dark UI, toggleable panel

(function() {
  'use strict';

  const STORAGE_KEY = 'xaiStatusData';
  let widgetContainer = null;
  let panel = null;
  let isOpen = false;
  let currentData = null;
  let updateInterval = null;

  // Detect if we're on status.x.ai for minor tweaks
  const isStatusPage = window.location.hostname.includes('status.x.ai');

  // Make any element draggable (used for FAB and panel)
  function makeDraggable(element, handle = null) {
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    let startX = 0, startY = 0;
    let hasMoved = false;
    const dragHandle = handle || element;

    dragHandle.onmousedown = dragMouseDown;

    function dragMouseDown(e) {
      if (e.target.closest('.grok-status-close') || e.target.closest('.grok-refresh-btn')) return;
      e.preventDefault();
      startX = e.clientX;
      startY = e.clientY;
      hasMoved = false;
      pos3 = e.clientX;
      pos4 = e.clientY;

      document.onmouseup = closeDragElement;
      document.onmousemove = elementDrag;
      element.style.transition = 'none';
    }

    function elementDrag(e) {
      e.preventDefault();
      const deltaX = Math.abs(e.clientX - startX);
      const deltaY = Math.abs(e.clientY - startY);
      if (deltaX > 4 || deltaY > 4) hasMoved = true;

      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;
      element.style.top = (element.offsetTop - pos2) + "px";
      element.style.left = (element.offsetLeft - pos1) + "px";
      element.style.bottom = 'auto';
      element.style.right = 'auto';
    }

    function closeDragElement() {
      document.onmouseup = null;
      document.onmousemove = null;
      element.style.transition = 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)';

      // Save position for persistence
      if (element.id === 'grok-status-widget') {
        chrome.storage.local.set({
          widgetPosition: {
            top: element.style.top,
            left: element.style.left
          }
        });
      }
    }

    // Store hasMoved flag on element for click detection
    element._hasMoved = () => hasMoved;
  }

  function createWidget() {
    if (widgetContainer) return;

    widgetContainer = document.createElement('div');
    widgetContainer.id = 'grok-status-widget';
    widgetContainer.className = 'grok-status-widget';

    // FAB (closed state)
    const fab = document.createElement('div');
    fab.className = 'grok-status-fab';
    fab.innerHTML = `
      <div class="grok-status-dot green" id="grok-status-dot"></div>
      <span class="grok-status-label">xAI Status</span>
    `;

    fab.addEventListener('click', (e) => {
      // Only open if it wasn't a drag
      if (!widgetContainer._hasMoved || !widgetContainer._hasMoved()) {
        togglePanel();
      }
    });

    widgetContainer.appendChild(fab);
    document.body.appendChild(widgetContainer);

    // Make FAB draggable
    makeDraggable(widgetContainer);

    // Initial load from storage
    loadAndRender();

    // Poll storage every 8 seconds for updates (in case storage event misses)
    if (updateInterval) clearInterval(updateInterval);
    updateInterval = setInterval(loadAndRender, 8000);

    // Listen for storage changes (immediate updates from background)
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes[STORAGE_KEY]) {
        currentData = changes[STORAGE_KEY].newValue;
        updateFAB();
        if (isOpen && panel) {
          renderPanelContent();
        }
      }
    });

    // Keyboard shortcut: Ctrl/Cmd + Shift + S
    document.addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 's') {
        e.preventDefault();
        togglePanel();
      }
    });

    console.log('[Status Indicator] Widget injected on', window.location.hostname);
  }

  function updateFAB() {
    if (!widgetContainer || !currentData) return;

    const dot = widgetContainer.querySelector('#grok-status-dot');
    if (!dot) return;

    dot.className = `grok-status-dot ${currentData.overallColor || 'green'}`;

    // Optional: subtle pulse if recent update
    if (currentData.lastFetched && (Date.now() - currentData.lastFetched < 60000)) {
      dot.style.boxShadow = `0 0 0 4px rgba(34, 197, 94, 0.25)`;
      setTimeout(() => {
        if (dot) dot.style.boxShadow = `0 0 0 3px rgba(34, 197, 94, 0.2)`;
      }, 1200);
    }
  }

  function togglePanel() {
    if (!widgetContainer) return;

    if (isOpen) {
      closePanel();
    } else {
      openPanel();
    }
  }

  function openPanel() {
    if (panel) {
      panel.style.display = 'flex';
      isOpen = true;
      return;
    }

    panel = document.createElement('div');
    panel.className = 'grok-status-panel';
    panel.innerHTML = `
      <div class="grok-status-header">
        <div class="grok-status-header-left">
          <div>
            <span class="grok-status-logo">xAI</span>
            <span style="font-weight:600; margin-left:4px; color:#a1a1aa;">Status</span>
          </div>
        </div>
        <div style="display:flex; align-items:center; gap:6px;">
          <div class="grok-status-updated" id="panel-updated">Updated just now</div>
          
          <!-- Timezone selector -->
          <select id="tz-select" style="font-size:10px; background:#27272a; color:#9ca3af; border:1px solid #3f3f46; border-radius:4px; padding:1px 5px; height:18px;">
            <option value="auto">Auto</option>
            <option value="UTC">UTC</option>
            <option value="MDT">MDT</option>
            <option value="PDT">PDT</option>
            <option value="EDT">EDT</option>
            <option value="CET">CET</option>
            <option value="CEST">CEST</option>
          </select>
          
          <div class="grok-status-close" id="panel-close">✕</div>
        </div>
      </div>
      <div class="grok-status-body" id="panel-body">
        <!-- Dynamic content injected here -->
      </div>
      <div class="grok-status-footer">
        <a href="https://status.x.ai/" target="_blank" class="grok-footer-link">
          <span>View full dashboard</span>
        </a>
        
        <div style="font-size: 9.5px; color: #6b7280; display: flex; align-items: center; gap: 4px;">
          <span>by</span> 
          <a href="https://x.com/StarlightSyntax" target="_blank" style="color: #a1a1aa; text-decoration: none; font-weight: 600;">@StarlightSyntax</a>
          <span style="color: #4b5563;">•</span>
          <span style="color: #8b5cf6; font-weight: 600;">Grok</span>
        </div>
        
        <button class="grok-refresh-btn" id="panel-refresh">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.058 11H1M12 3v2m0 16v2m9-9H15m-6 0a8 8 0 01-.582-15.356"/></svg>
          <span>Refresh</span>
        </button>
      </div>
    `;

    // Smart positioning: Prefer opening to the LEFT of the widget (right side faces center)
    // and above it, while staying inside the viewport
    const rect = widgetContainer.getBoundingClientRect();
    const panelWidth = 420;
    const panelHeight = 560;
    const padding = 16;

    let left = rect.left - panelWidth - 12;  // Open to the left by default
    let top = Math.max(padding, rect.top - panelHeight - 12);

    // If not enough space on left, open to the right instead
    if (left < padding) {
      left = rect.right + 12;
    }

    // If still going off right edge, clamp it
    if (left + panelWidth > window.innerWidth - padding) {
      left = window.innerWidth - panelWidth - padding;
    }

    // Final safety clamp for top
    if (top + panelHeight > window.innerHeight - padding) {
      top = Math.max(padding, window.innerHeight - panelHeight - padding);
    }

    panel.style.bottom = 'auto';
    panel.style.right = 'auto';
    panel.style.top = top + 'px';
    panel.style.left = left + 'px';

    document.body.appendChild(panel);
    isOpen = true;

    // Make panel draggable (header is the handle)
    const header = panel.querySelector('.grok-status-header');
    if (header) makeDraggable(panel, header);

    // Event listeners
    panel.querySelector('#panel-close').addEventListener('click', closePanel);
    
    // Timezone selector - always functional
    const tzSelect = panel.querySelector('#tz-select');
    if (tzSelect) {
      // Set default value
      chrome.storage.local.get('preferredTimezone', (result) => {
        tzSelect.value = result.preferredTimezone || (currentData && currentData.timeZone) || 'auto';
      });
      
      tzSelect.onchange = () => {
        chrome.storage.local.set({ preferredTimezone: tzSelect.value });
      };
    }
    
    panel.querySelector('#panel-refresh').addEventListener('click', async () => {
      const btn = panel.querySelector('#panel-refresh');
      btn.style.opacity = '0.5';
      btn.style.pointerEvents = 'none';
      
      // Trigger background refresh
      chrome.runtime.sendMessage({ type: 'FORCE_REFRESH' }, (response) => {
        if (response && response.success) {
          currentData = response.data;
          renderPanelContent();
        }
        btn.style.opacity = '1';
        btn.style.pointerEvents = 'auto';
      });
    });

    // Click outside to close (but not on the widget itself)
    setTimeout(() => {
      document.addEventListener('click', handleOutsideClick, { once: true });
    }, 100);

    renderPanelContent();
    
    // Event delegation for service pills (more reliable)
    panel.addEventListener('click', (e) => {
      const pill = e.target.closest('.grok-service-pill');
      if (pill) {
        e.stopImmediatePropagation();
        const serviceName = pill.getAttribute('data-service');
        const serviceUrl = pill.getAttribute('data-url');
        showServiceModal(serviceName, serviceUrl);
      }
    });
  }

  function closePanel() {
    if (panel) {
      panel.style.animation = 'grokSlideUp 0.2s reverse forwards';
      setTimeout(() => {
        if (panel && panel.parentNode) panel.parentNode.removeChild(panel);
        panel = null;
        isOpen = false;
      }, 180);
    }
  }

  function handleOutsideClick(e) {
    // Don't close if clicking inside a modal
    if (document.querySelector('[style*="z-index: 2147483648"]')) return;
    
    if (panel && !panel.contains(e.target) && !widgetContainer.contains(e.target)) {
      closePanel();
    }
  }

  // Map service names to their status page URLs
  function getServiceUrl(serviceName) {
    const map = {
      'Grok (Web)': 'https://status.x.ai/grok-com',
      'Grok (iOS)': 'https://status.x.ai/ios-app',
      'Grok (Android)': 'https://status.x.ai/android-app',
      'Single Sign-On': 'https://status.x.ai/sso',
      'API (us-east-1.api.x.ai)': 'https://status.x.ai/api-us-east-1',
      'API (eu-west-1.api.x.ai)': 'https://status.x.ai/api-eu-west-1',
      'API Console': 'https://status.x.ai/api-console',
      'Docs': 'https://status.x.ai/docs',
      'xAI Website': 'https://status.x.ai/xai-website',
      'Grok in X': 'https://status.x.ai/grok-x'
    };
    return map[serviceName] || 'https://status.x.ai/';
  }

  // Show detailed service modal
  function showServiceModal(serviceName, serviceUrl) {
    const modal = document.createElement('div');
    modal.style.cssText = `
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(0,0,0,0.7); z-index: 2147483648;
      display: flex; align-items: center; justify-content: center;
    `;
    
    modal.innerHTML = `
      <div style="background: #141418; border: 1px solid #27272a; border-radius: 16px; width: 340px; max-width: 90%; box-shadow: 0 25px 50px -12px rgb(0 0 0 / 0.5);">
        <div style="padding: 18px 20px; border-bottom: 1px solid #27272a; display: flex; justify-content: space-between; align-items: center;">
          <div style="font-weight: 700; font-size: 15px;">${serviceName}</div>
          <div style="cursor: pointer; color: #9ca3af; font-size: 18px;" id="modal-close">✕</div>
        </div>
        
        <div style="padding: 20px;">
          <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 16px;">
            <div style="width: 10px; height: 10px; background: #22c55e; border-radius: 50%;"></div>
            <span style="font-weight: 600; color: #22c55e;">Available / Operational</span>
          </div>
          
          <div style="font-size: 13px; color: #a1a1aa; line-height: 1.5;">
            This service is currently running normally.<br>
            No active incidents reported.
          </div>
        </div>
        
        <div style="padding: 14px 20px; background: #1f2228; border-top: 1px solid #27272a; border-radius: 0 0 16px 16px;">
          <a href="${serviceUrl}" target="_blank" 
             style="display: block; text-align: center; background: #27272a; color: #fff; padding: 9px 16px; border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 13px;">
            View Full Status on status.x.ai →
          </a>
        </div>
      </div>
    `;
    
    document.body.appendChild(modal);
    
    modal.querySelector('#modal-close').onclick = () => modal.remove();
    modal.onclick = (e) => {
      if (e.target === modal) modal.remove();
    };
  }

  function renderPanelContent() {
    if (!panel || !currentData) return;

    const body = panel.querySelector('#panel-body');
    const updatedEl = panel.querySelector('#panel-updated');
    if (!body || !updatedEl) return;

    updatedEl.textContent = `Updated ${currentData.lastUpdated || 'recently'}`;

    let html = '';

    // Overall banner
    const colorClass = currentData.overallColor || 'green';
    html += `
      <div class="grok-overall-banner ${colorClass}">
        <div class="grok-overall-icon">
          ${currentData.overallColor === 'green' ? 
            `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>` : 
            currentData.overallColor === 'yellow' ? 
            `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 9v2m0 4h.01M21 12a9 9 0 01-9 9 9 9 0 01-9-9 9 9 0 019-9 9 9 0 019 9z"/></svg>` :
            `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`
          }
        </div>
        <div>
          <div style="font-weight:700; font-size:15px;">${currentData.overall}</div>
          ${currentData.hasIncidents ? '<div style="font-size:11px; opacity:0.85;">Some services may be affected</div>' : ''}
        </div>
      </div>
    `;

    // Services section
    if (currentData.services && currentData.services.length > 0) {
      html += `<div class="grok-section-header">Services</div>`;
      html += `<div class="grok-services-grid">`;
      currentData.services.forEach(svc => {
        const serviceUrl = getServiceUrl(svc.name);
        html += `
          <div class="grok-service-pill" data-service="${svc.name}" data-url="${serviceUrl}">
            <div class="dot"></div>
            <span>${svc.name}</span>
          </div>
        `;
      });
      html += `</div>`;
    }

    // Live Metrics - Beautiful colored squares (matching status.x.ai)
    if (currentData.liveData && currentData.liveData.length > 0) {
      html += `<div class="grok-section-header">Live Service Data</div>`;
      html += `<div class="grok-metrics-grid">`;
      
      currentData.liveData.forEach(metric => {
        const infColor = metric.inference >= 99.5 ? '#16a34a' : metric.inference >= 99 ? '#ca8a04' : '#b45309';
        const nonColor = metric.nonInference >= 99.5 ? '#16a34a' : '#ca8a04';
        
        html += `
          <div class="grok-metric-square" style="background: linear-gradient(145deg, ${infColor}22, #2a2a30); border: 1px solid ${infColor}44;">
            <div class="region">${metric.endpoint}</div>
            <div class="value" style="color: ${infColor};">${metric.inference.toFixed(2)}%</div>
            <div class="type">Inference</div>
          </div>
          <div class="grok-metric-square" style="background: linear-gradient(145deg, ${nonColor}22, #2a2a30); border: 1px solid ${nonColor}44;">
            <div class="region">${metric.endpoint}</div>
            <div class="value" style="color: ${nonColor};">${metric.nonInference.toFixed(2)}%</div>
            <div class="type">Non-inference</div>
          </div>
        `;
      });
      
      html += `</div>`;
    }

    // Models
    if (currentData.models && currentData.models.length > 0) {
      html += `<div class="grok-section-header">Model Latencies (ITL)</div>`;
      html += `<div class="grok-models-list">`;
      currentData.models.slice(0, 12).forEach(model => {  // show top 12 fastest
        html += `
          <div class="grok-model-row">
            <span class="grok-model-name">${model.name}</span>
            <span class="grok-model-latency">${model.latency} ms</span>
          </div>
        `;
      });
      if (currentData.models.length > 12) {
        html += `<div style="padding:4px 14px; font-size:11px; color:#6b7280; text-align:center;">+${currentData.models.length - 12} more models • Full list on status.x.ai</div>`;
      }
      html += `</div>`;
    }

    // Error notice
    if (currentData.fetchError) {
      html += `<div class="grok-error">⚠ Could not refresh live data: ${currentData.fetchError}. Showing cached values.</div>`;
    }

    body.innerHTML = html;
  }

  async function loadAndRender() {
    try {
      const result = await chrome.storage.local.get(STORAGE_KEY);
      currentData = result[STORAGE_KEY];

      if (!currentData) {
        // First time or no data yet - trigger background fetch
        chrome.runtime.sendMessage({ type: 'FORCE_REFRESH' });
        return;
      }

      updateFAB();

      if (isOpen && panel) {
        renderPanelContent();
      }
    } catch (e) {
      console.warn('[Status Indicator] Storage read error:', e);
    }
  }

  // Boot the widget
  function init() {
    // Avoid injecting multiple times (e.g. on SPA navigation)
    if (document.getElementById('grok-status-widget')) return;

    createWidget();

    // On status.x.ai, auto-open once after short delay (nice UX)
    if (isStatusPage) {
      setTimeout(() => {
        if (!isOpen && widgetContainer) {
          // Don't auto-open every time, only if user hasn't interacted
          const hasInteracted = sessionStorage.getItem('status-widget-interacted');
          if (!hasInteracted) {
            openPanel();
            sessionStorage.setItem('status-widget-interacted', 'true');
          }
        }
      }, 1400);
    }

    // Expose for debugging
    window.__GROK_STATUS_INDICATOR__ = { toggle: togglePanel, refresh: () => chrome.runtime.sendMessage({type:'FORCE_REFRESH'}) };
  }

  // Wait for body to be ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Cleanup on unload (rarely needed)
  window.addEventListener('beforeunload', () => {
    if (updateInterval) clearInterval(updateInterval);
  });

})();
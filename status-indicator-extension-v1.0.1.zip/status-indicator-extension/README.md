# Status Indicator for Grok & xAI

**A lightweight, beautiful, always-up-to-date status widget** that lives directly on `grok.com` and `status.x.ai`.

- **Native Grok UI** — Dark minimalist design matching xAI/grok.com aesthetic (almost-black cards, high-contrast typography, subtle purple accents, smooth animations).
- **Live updates** — Pulls real-time data straight from https://status.x.ai every ~45 seconds (no external APIs or CDNs).
- **Small & non-intrusive** — Collapsible floating widget (closed = elegant pill with status dot; open = rich panel with services, uptime %, model latencies).
- **Works everywhere** — Content script on grok.com + status.x.ai. Bonus: Click the extension icon in toolbar for instant popup status from any tab.
- **Fully local** — 100% self-contained. No tracking, no external dependencies.
- **Cross-browser** — Manifest V3 (Chrome + Firefox compatible).

## Features

- Overall system status banner (green/yellow/red)
- All monitored services with "Available" badges
- Live regional uptime (Inference / Non-inference % for eu-west-1 & us-east-1)
- Model latencies (ITL in ms) — sorted fastest first
- Relative "last updated" timestamps
- Manual refresh button
- Keyboard shortcut: `Ctrl/Cmd + Shift + S`
- Auto-opens once on status.x.ai for convenience
- Error handling with cached fallback

## Installation (Developer Mode)

### Chrome / Edge / Brave
1. Download / clone this folder.
2. Go to `chrome://extensions/`
3. Enable **Developer mode** (top right)
4. Click **Load unpacked**
5. Select the `status-indicator-extension` folder
6. Pin the extension (optional)

### Firefox (Recommended Steps)
1. Open Firefox and go to `about:debugging#/runtime/this-firefox`
2. Click the **"Load Temporary Add-on..."** button
3. Navigate to and select the **`manifest.json`** file inside the `status-indicator-extension` folder
4. The extension should appear in the list. Click the **"Inspect"** button next to it if you want to see console logs.
5. Visit `grok.com` or `status.x.ai` — the widget should appear in the bottom-right corner.

**Firefox Troubleshooting (if it doesn't load):**
- Make sure you are using Firefox 128+ (Manifest V3 is fully supported).
- If you get a "corrupted" or permission error, try reloading the add-on (click the reload icon in about:debugging).
- For **permanent installation** (recommended for daily use):
  - Install `web-ext` globally: `npm install -g web-ext`
  - In the extension folder, run: `web-ext run` (for testing) or `web-ext build` to create a `.xpi` file.
  - Or use the official "Extension Workshop" signing process for production.
- If alarms or background script seem inactive: Go to `about:config` and ensure `extensions.webextensions.backgroundServiceWorker.enabled` is `true` (it should be by default in modern Firefox).

The icons are now proper PNG files (generated with Grok-inspired purple + green status design) for maximum compatibility.

### Important: Firefox .xpi Limitation (Why it says "corrupted")
Modern Firefox is very strict. Unsigned `.xpi` files (like the one I provided) often show **"This add-on could not be installed because it appears to be corrupt"**.

**This is normal and expected** for developer-built extensions.

### Recommended Firefox Installation (Works Every Time)
Use the **folder method** via debugging page:

1. Extract the `.zip` file (or use the folder directly).
2. Open Firefox and go to this exact address:  
   **`about:debugging#/runtime/this-firefox`**
3. Click the big button **"Load Temporary Add-on..."**
4. Select the file named **`manifest.json`** inside the `status-indicator-extension` folder.
5. The extension will appear in the list (you should see the purple/green icon).
6. Go to `grok.com` or `status.x.ai` — the Status Indicator widget should now be visible in the bottom-right corner.

**Tip**: If it doesn't appear immediately, click the **reload** icon (circular arrows) next to the extension name in the debugging page.

## How It Works

1. Background service worker fetches https://status.x.ai/ periodically.
2. Parses the HTML (robust text + regex extraction for services, metrics, models).
3. Stores clean JSON in `chrome.storage.local`.
4. Content script on supported domains injects the floating widget and listens for updates.
5. UI updates instantly — no page reload needed.

## Customization Ideas (Advanced)

- Edit `styles.css` to tweak colors or spacing.
- Change update interval in `background.js` (`UPDATE_INTERVAL_MINUTES`).
- Add more models or custom thresholds.

## Known Limitations

- Parsing relies on the current structure of status.x.ai. If xAI changes the page layout significantly, the extractor may need minor updates (easy to fix — open an issue).
- No real-time WebSocket push (uses polling + storage events for near-instant feel).
- On very rare fetch failures, shows last cached data.

## Credits & Philosophy

Built with maximum truth-seeking and minimalism in mind — exactly what you'd expect from a Grok-native tool.

Created for StarlightSyntax by Grok 4.20 Heavy (multi-agent swarm).

---

**Enjoy real-time visibility into xAI's infrastructure while chatting with Grok.** 

If you love it, star the repo or share feedback! 

For issues: Check console logs (`background.js` and content script) or open the popup and hit Refresh.
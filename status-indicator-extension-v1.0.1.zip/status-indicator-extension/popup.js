// popup.js - Toolbar popup for Status Indicator
// Reads from storage, allows manual refresh, opens grok.com

const STORAGE_KEY = 'xaiStatusData';

function renderPopup(data) {
  const body = document.getElementById('popup-body');
  const updated = document.getElementById('popup-updated');
  
  if (!data) {
    body.innerHTML = `<div style="padding:20px; text-align:center; color:#6b7280;">No status data yet.<br>Click Refresh.</div>`;
    return;
  }

  updated.textContent = `Updated ${data.lastUpdated || 'recently'}`;

  let html = '';

  // Overall
  const color = data.overallColor || 'green';
  html += `
    <div class="overall ${color}">
      <div style="font-size:18px; line-height:1;">${color === 'green' ? '✓' : color === 'yellow' ? '⚠' : '✕'}</div>
      <div>
        <div style="font-weight:700;">${data.overall}</div>
      </div>
    </div>
  `;

  // Services
  if (data.services && data.services.length) {
    html += `<div class="section"><div class="section-title">Active Services</div>`;
    data.services.slice(0, 6).forEach(s => {
      html += `<div class="service"><div class="dot"></div> <span>${s.name}</span></div>`;
    });
    html += `</div>`;
  }

  // Metrics
  if (data.liveData && data.liveData.length) {
    html += `<div class="section"><div class="section-title">Regional Uptime</div>`;
    data.liveData.forEach(m => {
      html += `
        <div class="metric">
          <span style="font-weight:600;">${m.endpoint}</span>
          <span style="font-variant-numeric:tabular-nums; font-weight:700; color:#22c55e;">${m.inference}% / ${m.nonInference}%</span>
        </div>
      `;
    });
    html += `</div>`;
  }

  // Models (top 5)
  if (data.models && data.models.length) {
    html += `<div class="section"><div class="section-title">Fastest Models (ITL)</div>`;
    data.models.slice(0, 5).forEach(m => {
      html += `
        <div class="model">
          <span>${m.name}</span>
          <span class="latency">${m.latency}ms</span>
        </div>
      `;
    });
    html += `</div>`;
  }

  if (data.fetchError) {
    html += `<div class="error">Live fetch failed: ${data.fetchError}</div>`;
  }

  body.innerHTML = html;
}

async function loadData() {
  const result = await chrome.storage.local.get(STORAGE_KEY);
  renderPopup(result[STORAGE_KEY]);
}

async function refresh() {
  const btn = document.getElementById('refresh-btn');
  btn.textContent = 'Refreshing...';
  btn.disabled = true;

  chrome.runtime.sendMessage({ type: 'FORCE_REFRESH' }, (response) => {
    if (response && response.success) {
      renderPopup(response.data);
    } else {
      loadData(); // fallback to cached
    }
    btn.textContent = '⟳ Refresh Now';
    btn.disabled = false;
  });
}

function initPopup() {
  loadData();

  document.getElementById('refresh-btn').addEventListener('click', refresh);
  
  document.getElementById('open-grok-btn').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://grok.com' });
    window.close();
  });

  // Auto-refresh popup every 20s while open
  setInterval(loadData, 20000);
}

document.addEventListener('DOMContentLoaded', initPopup);